﻿namespace GuessTheWord
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.button_A = new System.Windows.Forms.Button();
            this.button_B = new System.Windows.Forms.Button();
            this.button_C = new System.Windows.Forms.Button();
            this.button_D = new System.Windows.Forms.Button();
            this.button_E = new System.Windows.Forms.Button();
            this.button_F = new System.Windows.Forms.Button();
            this.button_G = new System.Windows.Forms.Button();
            this.button_H = new System.Windows.Forms.Button();
            this.button_M = new System.Windows.Forms.Button();
            this.button_N = new System.Windows.Forms.Button();
            this.button_O = new System.Windows.Forms.Button();
            this.button_P = new System.Windows.Forms.Button();
            this.button_K = new System.Windows.Forms.Button();
            this.button_L = new System.Windows.Forms.Button();
            this.button_J = new System.Windows.Forms.Button();
            this.button_I = new System.Windows.Forms.Button();
            this.button_U = new System.Windows.Forms.Button();
            this.button_V = new System.Windows.Forms.Button();
            this.button_W = new System.Windows.Forms.Button();
            this.button_X = new System.Windows.Forms.Button();
            this.button_S = new System.Windows.Forms.Button();
            this.button_T = new System.Windows.Forms.Button();
            this.button_R = new System.Windows.Forms.Button();
            this.button_Q = new System.Windows.Forms.Button();
            this.button_Z = new System.Windows.Forms.Button();
            this.button_Y = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label_Word = new System.Windows.Forms.Label();
            this.label_MissedLetters = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.button_LoadNewWord = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label_MissedLtrCnt = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.btnSair = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // button_A
            // 
            this.button_A.Location = new System.Drawing.Point(15, 31);
            this.button_A.Name = "button_A";
            this.button_A.Size = new System.Drawing.Size(38, 23);
            this.button_A.TabIndex = 0;
            this.button_A.Text = "A";
            this.button_A.UseVisualStyleBackColor = true;
            this.button_A.Click += new System.EventHandler(this.button_A_Click);
            // 
            // button_B
            // 
            this.button_B.Location = new System.Drawing.Point(59, 31);
            this.button_B.Name = "button_B";
            this.button_B.Size = new System.Drawing.Size(38, 23);
            this.button_B.TabIndex = 1;
            this.button_B.Text = "B";
            this.button_B.UseVisualStyleBackColor = true;
            this.button_B.Click += new System.EventHandler(this.button_B_Click);
            // 
            // button_C
            // 
            this.button_C.Location = new System.Drawing.Point(103, 31);
            this.button_C.Name = "button_C";
            this.button_C.Size = new System.Drawing.Size(38, 23);
            this.button_C.TabIndex = 3;
            this.button_C.Text = "C";
            this.button_C.UseVisualStyleBackColor = true;
            this.button_C.Click += new System.EventHandler(this.button_C_Click);
            // 
            // button_D
            // 
            this.button_D.Location = new System.Drawing.Point(147, 31);
            this.button_D.Name = "button_D";
            this.button_D.Size = new System.Drawing.Size(38, 23);
            this.button_D.TabIndex = 2;
            this.button_D.Text = "D";
            this.button_D.UseVisualStyleBackColor = true;
            this.button_D.Click += new System.EventHandler(this.button_D_Click);
            // 
            // button_E
            // 
            this.button_E.Location = new System.Drawing.Point(191, 31);
            this.button_E.Name = "button_E";
            this.button_E.Size = new System.Drawing.Size(38, 23);
            this.button_E.TabIndex = 7;
            this.button_E.Text = "E";
            this.button_E.UseVisualStyleBackColor = true;
            this.button_E.Click += new System.EventHandler(this.button_E_Click);
            // 
            // button_F
            // 
            this.button_F.Location = new System.Drawing.Point(235, 31);
            this.button_F.Name = "button_F";
            this.button_F.Size = new System.Drawing.Size(38, 23);
            this.button_F.TabIndex = 6;
            this.button_F.Text = "F";
            this.button_F.UseVisualStyleBackColor = true;
            this.button_F.Click += new System.EventHandler(this.button_F_Click);
            // 
            // button_G
            // 
            this.button_G.Location = new System.Drawing.Point(279, 31);
            this.button_G.Name = "button_G";
            this.button_G.Size = new System.Drawing.Size(38, 23);
            this.button_G.TabIndex = 5;
            this.button_G.Text = "G";
            this.button_G.UseVisualStyleBackColor = true;
            this.button_G.Click += new System.EventHandler(this.button_G_Click);
            // 
            // button_H
            // 
            this.button_H.Location = new System.Drawing.Point(323, 31);
            this.button_H.Name = "button_H";
            this.button_H.Size = new System.Drawing.Size(38, 23);
            this.button_H.TabIndex = 4;
            this.button_H.Text = "H";
            this.button_H.UseVisualStyleBackColor = true;
            this.button_H.Click += new System.EventHandler(this.button_H_Click);
            // 
            // button_M
            // 
            this.button_M.Location = new System.Drawing.Point(191, 60);
            this.button_M.Name = "button_M";
            this.button_M.Size = new System.Drawing.Size(38, 23);
            this.button_M.TabIndex = 15;
            this.button_M.Text = "M";
            this.button_M.UseVisualStyleBackColor = true;
            this.button_M.Click += new System.EventHandler(this.button_M_Click);
            // 
            // button_N
            // 
            this.button_N.Location = new System.Drawing.Point(235, 60);
            this.button_N.Name = "button_N";
            this.button_N.Size = new System.Drawing.Size(38, 23);
            this.button_N.TabIndex = 14;
            this.button_N.Text = "N";
            this.button_N.UseVisualStyleBackColor = true;
            this.button_N.Click += new System.EventHandler(this.button_N_Click);
            // 
            // button_O
            // 
            this.button_O.Location = new System.Drawing.Point(279, 60);
            this.button_O.Name = "button_O";
            this.button_O.Size = new System.Drawing.Size(38, 23);
            this.button_O.TabIndex = 13;
            this.button_O.Text = "O";
            this.button_O.UseVisualStyleBackColor = true;
            this.button_O.Click += new System.EventHandler(this.button_O_Click);
            // 
            // button_P
            // 
            this.button_P.Location = new System.Drawing.Point(323, 60);
            this.button_P.Name = "button_P";
            this.button_P.Size = new System.Drawing.Size(38, 23);
            this.button_P.TabIndex = 12;
            this.button_P.Text = "P";
            this.button_P.UseVisualStyleBackColor = true;
            this.button_P.Click += new System.EventHandler(this.button_P_Click);
            // 
            // button_K
            // 
            this.button_K.Location = new System.Drawing.Point(103, 60);
            this.button_K.Name = "button_K";
            this.button_K.Size = new System.Drawing.Size(38, 23);
            this.button_K.TabIndex = 11;
            this.button_K.Text = "K";
            this.button_K.UseVisualStyleBackColor = true;
            this.button_K.Click += new System.EventHandler(this.button_K_Click);
            // 
            // button_L
            // 
            this.button_L.Location = new System.Drawing.Point(147, 60);
            this.button_L.Name = "button_L";
            this.button_L.Size = new System.Drawing.Size(38, 23);
            this.button_L.TabIndex = 10;
            this.button_L.Text = "L";
            this.button_L.UseVisualStyleBackColor = true;
            this.button_L.Click += new System.EventHandler(this.button_L_Click);
            // 
            // button_J
            // 
            this.button_J.Location = new System.Drawing.Point(59, 60);
            this.button_J.Name = "button_J";
            this.button_J.Size = new System.Drawing.Size(38, 23);
            this.button_J.TabIndex = 9;
            this.button_J.Text = "J";
            this.button_J.UseVisualStyleBackColor = true;
            this.button_J.Click += new System.EventHandler(this.button_J_Click);
            // 
            // button_I
            // 
            this.button_I.Location = new System.Drawing.Point(15, 60);
            this.button_I.Name = "button_I";
            this.button_I.Size = new System.Drawing.Size(38, 23);
            this.button_I.TabIndex = 8;
            this.button_I.Text = "I";
            this.button_I.UseVisualStyleBackColor = true;
            this.button_I.Click += new System.EventHandler(this.button_I_Click);
            // 
            // button_U
            // 
            this.button_U.Location = new System.Drawing.Point(191, 89);
            this.button_U.Name = "button_U";
            this.button_U.Size = new System.Drawing.Size(38, 23);
            this.button_U.TabIndex = 23;
            this.button_U.Text = "U";
            this.button_U.UseVisualStyleBackColor = true;
            this.button_U.Click += new System.EventHandler(this.button_U_Click);
            // 
            // button_V
            // 
            this.button_V.Location = new System.Drawing.Point(235, 89);
            this.button_V.Name = "button_V";
            this.button_V.Size = new System.Drawing.Size(38, 23);
            this.button_V.TabIndex = 22;
            this.button_V.Text = "V";
            this.button_V.UseVisualStyleBackColor = true;
            this.button_V.Click += new System.EventHandler(this.button_V_Click);
            // 
            // button_W
            // 
            this.button_W.Location = new System.Drawing.Point(279, 89);
            this.button_W.Name = "button_W";
            this.button_W.Size = new System.Drawing.Size(38, 23);
            this.button_W.TabIndex = 21;
            this.button_W.Text = "W";
            this.button_W.UseVisualStyleBackColor = true;
            this.button_W.Click += new System.EventHandler(this.button_W_Click);
            // 
            // button_X
            // 
            this.button_X.Location = new System.Drawing.Point(323, 89);
            this.button_X.Name = "button_X";
            this.button_X.Size = new System.Drawing.Size(38, 23);
            this.button_X.TabIndex = 20;
            this.button_X.Text = "X";
            this.button_X.UseVisualStyleBackColor = true;
            this.button_X.Click += new System.EventHandler(this.button_X_Click);
            // 
            // button_S
            // 
            this.button_S.Location = new System.Drawing.Point(103, 89);
            this.button_S.Name = "button_S";
            this.button_S.Size = new System.Drawing.Size(38, 23);
            this.button_S.TabIndex = 19;
            this.button_S.Text = "S";
            this.button_S.UseVisualStyleBackColor = true;
            this.button_S.Click += new System.EventHandler(this.button_S_Click);
            // 
            // button_T
            // 
            this.button_T.Location = new System.Drawing.Point(147, 89);
            this.button_T.Name = "button_T";
            this.button_T.Size = new System.Drawing.Size(38, 23);
            this.button_T.TabIndex = 18;
            this.button_T.Text = "T";
            this.button_T.UseVisualStyleBackColor = true;
            this.button_T.Click += new System.EventHandler(this.button_T_Click);
            // 
            // button_R
            // 
            this.button_R.Location = new System.Drawing.Point(59, 89);
            this.button_R.Name = "button_R";
            this.button_R.Size = new System.Drawing.Size(38, 23);
            this.button_R.TabIndex = 17;
            this.button_R.Text = "R";
            this.button_R.UseVisualStyleBackColor = true;
            this.button_R.Click += new System.EventHandler(this.button_R_Click);
            // 
            // button_Q
            // 
            this.button_Q.Location = new System.Drawing.Point(15, 89);
            this.button_Q.Name = "button_Q";
            this.button_Q.Size = new System.Drawing.Size(38, 23);
            this.button_Q.TabIndex = 16;
            this.button_Q.Text = "Q";
            this.button_Q.UseVisualStyleBackColor = true;
            this.button_Q.Click += new System.EventHandler(this.button_Q_Click);
            // 
            // button_Z
            // 
            this.button_Z.Location = new System.Drawing.Point(191, 118);
            this.button_Z.Name = "button_Z";
            this.button_Z.Size = new System.Drawing.Size(38, 23);
            this.button_Z.TabIndex = 25;
            this.button_Z.Text = "Z";
            this.button_Z.UseVisualStyleBackColor = true;
            this.button_Z.Click += new System.EventHandler(this.button_Z_Click);
            // 
            // button_Y
            // 
            this.button_Y.Location = new System.Drawing.Point(147, 118);
            this.button_Y.Name = "button_Y";
            this.button_Y.Size = new System.Drawing.Size(38, 23);
            this.button_Y.TabIndex = 24;
            this.button_Y.Text = "Y";
            this.button_Y.UseVisualStyleBackColor = true;
            this.button_Y.Click += new System.EventHandler(this.button_Y_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label_Word);
            this.panel1.Location = new System.Drawing.Point(12, 16);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(374, 100);
            this.panel1.TabIndex = 26;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(4, 4);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(138, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Adivinhe a seguinte palavra";
            // 
            // label_Word
            // 
            this.label_Word.AutoSize = true;
            this.label_Word.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label_Word.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label_Word.Font = new System.Drawing.Font("Verdana", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Word.Location = new System.Drawing.Point(102, 33);
            this.label_Word.Name = "label_Word";
            this.label_Word.Size = new System.Drawing.Size(185, 37);
            this.label_Word.TabIndex = 0;
            this.label_Word.Text = "________";
            this.label_Word.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_MissedLetters
            // 
            this.label_MissedLetters.AutoSize = true;
            this.label_MissedLetters.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_MissedLetters.ForeColor = System.Drawing.Color.Red;
            this.label_MissedLetters.Location = new System.Drawing.Point(403, 50);
            this.label_MissedLetters.Name = "label_MissedLetters";
            this.label_MissedLetters.Size = new System.Drawing.Size(57, 20);
            this.label_MissedLetters.TabIndex = 27;
            this.label_MissedLetters.Text = "label1";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Blue;
            this.label1.Location = new System.Drawing.Point(403, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(157, 20);
            this.label1.TabIndex = 28;
            this.label1.Text = "Letras já informadas:";
            // 
            // button_LoadNewWord
            // 
            this.button_LoadNewWord.BackColor = System.Drawing.Color.White;
            this.button_LoadNewWord.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_LoadNewWord.Image = ((System.Drawing.Image)(resources.GetObject("button_LoadNewWord.Image")));
            this.button_LoadNewWord.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_LoadNewWord.Location = new System.Drawing.Point(219, 332);
            this.button_LoadNewWord.Name = "button_LoadNewWord";
            this.button_LoadNewWord.Size = new System.Drawing.Size(167, 72);
            this.button_LoadNewWord.TabIndex = 29;
            this.button_LoadNewWord.Text = "INICIAR";
            this.button_LoadNewWord.UseVisualStyleBackColor = false;
            this.button_LoadNewWord.Click += new System.EventHandler(this.button_LoadNewWord_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.groupBox1.Controls.Add(this.label_MissedLtrCnt);
            this.groupBox1.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.groupBox1.Location = new System.Drawing.Point(425, 145);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(167, 152);
            this.groupBox1.TabIndex = 30;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Número de chances";
            // 
            // label_MissedLtrCnt
            // 
            this.label_MissedLtrCnt.AutoSize = true;
            this.label_MissedLtrCnt.BackColor = System.Drawing.SystemColors.Desktop;
            this.label_MissedLtrCnt.Font = new System.Drawing.Font("Microsoft Sans Serif", 50F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_MissedLtrCnt.ForeColor = System.Drawing.Color.Gold;
            this.label_MissedLtrCnt.Location = new System.Drawing.Point(44, 41);
            this.label_MissedLtrCnt.Name = "label_MissedLtrCnt";
            this.label_MissedLtrCnt.Size = new System.Drawing.Size(71, 76);
            this.label_MissedLtrCnt.TabIndex = 0;
            this.label_MissedLtrCnt.Text = "5";
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.groupBox2.Controls.Add(this.button_C);
            this.groupBox2.Controls.Add(this.button_A);
            this.groupBox2.Controls.Add(this.button_B);
            this.groupBox2.Controls.Add(this.button_D);
            this.groupBox2.Controls.Add(this.button_H);
            this.groupBox2.Controls.Add(this.button_G);
            this.groupBox2.Controls.Add(this.button_Z);
            this.groupBox2.Controls.Add(this.button_F);
            this.groupBox2.Controls.Add(this.button_Y);
            this.groupBox2.Controls.Add(this.button_E);
            this.groupBox2.Controls.Add(this.button_U);
            this.groupBox2.Controls.Add(this.button_I);
            this.groupBox2.Controls.Add(this.button_V);
            this.groupBox2.Controls.Add(this.button_J);
            this.groupBox2.Controls.Add(this.button_W);
            this.groupBox2.Controls.Add(this.button_L);
            this.groupBox2.Controls.Add(this.button_X);
            this.groupBox2.Controls.Add(this.button_K);
            this.groupBox2.Controls.Add(this.button_S);
            this.groupBox2.Controls.Add(this.button_P);
            this.groupBox2.Controls.Add(this.button_T);
            this.groupBox2.Controls.Add(this.button_O);
            this.groupBox2.Controls.Add(this.button_R);
            this.groupBox2.Controls.Add(this.button_N);
            this.groupBox2.Controls.Add(this.button_Q);
            this.groupBox2.Controls.Add(this.button_M);
            this.groupBox2.Location = new System.Drawing.Point(12, 142);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(374, 155);
            this.groupBox2.TabIndex = 31;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Teclado";
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Location = new System.Drawing.Point(32, 362);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(165, 13);
            this.linkLabel1.TabIndex = 32;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "Adaptado por: www.macoratti.net";
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // btnSair
            // 
            this.btnSair.BackColor = System.Drawing.Color.White;
            this.btnSair.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSair.Image = ((System.Drawing.Image)(resources.GetObject("btnSair.Image")));
            this.btnSair.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSair.Location = new System.Drawing.Point(425, 332);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(167, 72);
            this.btnSair.TabIndex = 33;
            this.btnSair.Text = "SAIR";
            this.btnSair.UseVisualStyleBackColor = false;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(7, 20);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(67, 59);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 34;
            this.pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightBlue;
            this.ClientSize = new System.Drawing.Size(625, 413);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.linkLabel1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.button_LoadNewWord);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label_MissedLetters);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ADIVINHE A PALAVRA - (JOGO DA FORCA)";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button_A;
        private System.Windows.Forms.Button button_B;
        private System.Windows.Forms.Button button_C;
        private System.Windows.Forms.Button button_D;
        private System.Windows.Forms.Button button_E;
        private System.Windows.Forms.Button button_F;
        private System.Windows.Forms.Button button_G;
        private System.Windows.Forms.Button button_H;
        private System.Windows.Forms.Button button_M;
        private System.Windows.Forms.Button button_N;
        private System.Windows.Forms.Button button_O;
        private System.Windows.Forms.Button button_P;
        private System.Windows.Forms.Button button_K;
        private System.Windows.Forms.Button button_L;
        private System.Windows.Forms.Button button_J;
        private System.Windows.Forms.Button button_I;
        private System.Windows.Forms.Button button_U;
        private System.Windows.Forms.Button button_V;
        private System.Windows.Forms.Button button_W;
        private System.Windows.Forms.Button button_X;
        private System.Windows.Forms.Button button_S;
        private System.Windows.Forms.Button button_T;
        private System.Windows.Forms.Button button_R;
        private System.Windows.Forms.Button button_Q;
        private System.Windows.Forms.Button button_Z;
        private System.Windows.Forms.Button button_Y;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label_Word;
        private System.Windows.Forms.Label label_MissedLetters;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button_LoadNewWord;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label_MissedLtrCnt;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.Button btnSair;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

